package org.atm.bean;

public class User {

	private long checkBalance;
    private long withdrawalAmount;
    private long depositAmount;
    private int atmPin;
    private long cardNumber;
    
	public User() {
		super();
	}

	public User(long checkBalance, long withdrawalAmount, long depositAmount, int atmPin, long cardNumber) {
		super();
		this.checkBalance = checkBalance;
		this.withdrawalAmount = withdrawalAmount;
		this.depositAmount = depositAmount;
		this.atmPin = atmPin;
		this.cardNumber = cardNumber;
	}

	@Override
	public String toString() {
		return "User [checkBalance=" + checkBalance + ", withdrawalAmount=" + withdrawalAmount + ", depositAmount="
				+ depositAmount + ", atmPin=" + atmPin + ", cardNumber=" + cardNumber + "]";
	}

	public long getCheckBalance() {
		return checkBalance;
	}

	public void setCheckBalance(long checkBalance) {
		this.checkBalance = checkBalance;
	}

	public long getWithdrawalAmount() {
		return withdrawalAmount;
	}

	public void setWithdrawalAmount(long withdrawalAmount) {
		this.withdrawalAmount = withdrawalAmount;
	}

	public long getDepositAmount() {
		return depositAmount;
	}

	public void setDepositAmount(long depositAmount) {
		this.depositAmount = depositAmount;
	}

	public int getAtmPin() {
		return atmPin;
	}

	public void setAtmPin(int atmPin) {
		this.atmPin = atmPin;
	}

	public long getCardNumber() {
		return cardNumber;
	}

	public void setCardNumber(long cardNumber) {
		this.cardNumber = cardNumber;
	}

	
}
