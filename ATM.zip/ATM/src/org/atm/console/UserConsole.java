package org.atm.console;

import java.util.Scanner;

import org.atm.bean.User;
import org.atm.service.AtmService;
import org.atm.service.AtmServiceImpl;

public class UserConsole {

	public void start(long cardNum) {

		User user = new User();
		AtmService service = new AtmServiceImpl();
		Scanner s = new Scanner(System.in);
		while (true) {
			System.out.println("Welcome !!");
			System.out.println("Choose 1 for Withdraw");
			System.out.println("Choose 2 for Deposit");
			System.out.println("Choose 3 for Check Balance");
			System.out.println("Choose 4 for EXIT");
			System.out.print("Choose the operation you want to perform:");
			int n = s.nextInt();
			switch (n) {
			case 1:
				System.out.print("Enter money to be withdrawn:");
				boolean res = service.withdraw(s.nextLong(),cardNum);
				if (res == true) {
					System.out.println("Please collect your money");
				    System.out.println("Remaining balance is :" + service.checkBalance(cardNum));
				}
				else {
					System.out.println("Insufficient Balance");
				}
				System.out.println("");
				break;
			case 2:
				System.out.print("Enter money to be deposited:");
				boolean result = service.deposit(s.nextLong(),cardNum);
				if (result == true) {
					System.out.println("Your Money has been successfully depsited");
					System.out.println("Updated balance is :" + service.checkBalance(cardNum));
				} else {
					System.err.println("Technical Error occured please try later");
				}
				System.out.println("");
				break;
			case 3:
				long balance = service.checkBalance(cardNum);
				if (balance >= 0)
					System.out.println("Balance : " + balance);
				else {
					System.err.println("Technical Error occuured while fetching details. Please try later");
				}
				System.out.println("");
				break;

			case 4:
				System.exit(0);
			}
		}

	}

}
