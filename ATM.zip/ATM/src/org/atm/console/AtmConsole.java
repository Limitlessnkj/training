package org.atm.console;
import java.util.Scanner;

import org.atm.bean.User;
import org.atm.service.AtmService;
import org.atm.service.AtmServiceImpl;

public class AtmConsole
{
    public static void main(String args[])
    {  
    	User user=new User();
    	UserConsole console=new UserConsole();
        AtmService service=new AtmServiceImpl();
    	Scanner s = new Scanner(System.in);
    	 while(true)
	        {
	            System.out.println("Automated Teller Machine");
	            System.out.println("Please Enter your debit card number");
	            long cardNum=s.nextInt();
	            System.out.println("Please Enter your 4 digit pin");
	            int pin=s.nextInt();
	            System.out.println(cardNum+ " "+pin);
	            boolean value= service.validateCard(cardNum,pin);
	            if(value==true)
	            	console.start(cardNum);
	            else {
	            	System.err.println("Sorry,Pin entered is incorrect !!");
	            	return;
	            }
	        }
		
	}
    }
