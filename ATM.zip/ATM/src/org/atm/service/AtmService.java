package org.atm.service;

public interface AtmService {

	boolean validateCard(long cardNum, int pin);

	boolean withdraw(long withdraw, long cardNum);

	boolean deposit(long deposit, long cardNum);

	long checkBalance(long cardNum);

}
