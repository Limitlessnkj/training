package org.atm.service;

import org.atm.dao.AtmDao;
import org.atm.dao.AtmDaoImpl;

public class AtmServiceImpl implements AtmService {
	AtmDao dao=new AtmDaoImpl();

	@Override
	public boolean validateCard(long cardNum, int pin) {
		return dao.validateCard(cardNum, pin);
	}

	@Override
	public boolean withdraw(long withdraw,long cardNum) {
		return dao.withdraw(withdraw,cardNum);
	}

	@Override
	public boolean deposit(long deposit,long cardNum) {
		return dao.deposit(deposit,cardNum);
	}

	@Override
	public long checkBalance(long cardNum) {
		return dao.checkBalance(cardNum);
	}

}
