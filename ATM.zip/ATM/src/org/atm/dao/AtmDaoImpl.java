package org.atm.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.atm.bean.User;

public class AtmDaoImpl implements AtmDao {

	// JDBC driver name and database URL
	static final String JDBC_DRIVER = "com.mysql.jdbc.Driver";
	static final String DB_URL = "jdbc:mysql://localhost:3306/ATMsystem";

	// Database credentials
	static final String USER = "root";
	static final String PASS = "0403";
	User user = new User();

	@Override
	public boolean validateCard(long cardNum, int pin) {
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean result = false;
		try {
			// STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");
			//DriverManager.registerDriver(new com.mysql.jdbc.Driver());

			// STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// STEP 4: Execute a query

			String sql = "SELECT * FROM UserInfo WHERE cardNumber=? AND atmPin=?";
			stmt = conn.prepareStatement(sql);
			stmt.setLong(1, cardNum);
			stmt.setInt(2, pin);
			ResultSet rs = stmt.executeQuery();
			// STEP 5: Extract data from result set
			if (rs.next()) {
				result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// STEP 6: Clean-up environment
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public boolean withdraw(long withdraw,long cardNum) {
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean result = false;
		long balance = 0;
		try {
			balance = checkBalance(cardNum);
			if (balance >= withdraw) {
				balance = balance - withdraw;
				// STEP 2: Register JDBC driver
				Class.forName("com.mysql.jdbc.Driver");

				// STEP 3: Open a connection
				conn = DriverManager.getConnection(DB_URL, USER, PASS);

				// STEP 4: Execute a query

				String sql = "UPDATE UserInfo SET checkBalance=?, withdrawalAmount=? WHERE cardNumber=?";
				stmt = conn.prepareStatement(sql);
				stmt.setLong(1, balance);
				stmt.setLong(2, withdraw);
				stmt.setLong(3, cardNum);
				int update = stmt.executeUpdate();
				if (update > 0)
					result = true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// STEP 6: Clean-up environment
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public boolean deposit(long deposit,long cardNum) {
		Connection conn = null;
		PreparedStatement stmt = null;
		boolean result = false;
		long balance = 0;
		try {
			balance = checkBalance(cardNum);
			balance = balance + deposit;
			// STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL, USER, PASS);
			
			// STEP 4: Execute a query
			String sql = "UPDATE UserInfo SET checkBalance=?, depositAmount=? WHERE cardNumber=?";
			stmt = conn.prepareStatement(sql);
			stmt.setLong(1, balance);
			stmt.setLong(2, deposit);
			stmt.setLong(3, cardNum);
			int update = stmt.executeUpdate();
			if (update > 0)
				result = true;
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// STEP 6: Clean-up environment
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return result;
	}

	@Override
	public long checkBalance(long cardNum) {
		Connection conn = null;
		PreparedStatement stmt = null;
		long balance=-1;
		try {
			// STEP 2: Register JDBC driver
			Class.forName("com.mysql.jdbc.Driver");

			// STEP 3: Open a connection
			conn = DriverManager.getConnection(DB_URL, USER, PASS);

			// STEP 4: Execute a query

			String sql = "SELECT checkBalance FROM UserInfo where cardNumber=?";
			stmt = conn.prepareStatement(sql);
			stmt.setLong(1, cardNum);
			ResultSet rs = stmt.executeQuery();
			// STEP 5: Extract data from result set
			if(rs.next()) {
				 balance = rs.getLong("checkBalance");
			}
		} catch (SQLException e) {
			e.printStackTrace();
		} catch (ClassNotFoundException e) {
			e.printStackTrace();
		} finally {
			try {
				// STEP 6: Clean-up environment
				stmt.close();
				conn.close();
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
		return balance;
	}

}
