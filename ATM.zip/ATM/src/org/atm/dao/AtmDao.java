package org.atm.dao;

public interface AtmDao {

	boolean validateCard(long cardNum, int pin);

	boolean withdraw(long withdraw, long cardNum);

	boolean deposit(long deposit, long cardNum);

	long checkBalance(long cardNum);

}
